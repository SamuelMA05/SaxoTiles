import { calcularDestinos, cargarMidi, iniciarLoop,
         activarNota, getNotasEnPantalla, getStartTime } from "./motor.js";
import { VELOCIDAD, VENTANA_HIT } from "./config.js";

let score = 0, racha = 0, maxRacha = 0;

const elScore  = document.getElementById("hud-score");
const elRacha  = document.getElementById("hud-racha");
const elMax    = document.getElementById("hud-max");

function actualizarPantalla() {
    elScore.textContent = `Puntuación: ${score}`;
    elRacha.textContent = `Racha ${racha}`;
    elMax.textContent   = `Racha Máxima: ${maxRacha}`;
}


function mostrarFeedback(texto, color, x, y) {
    const el = document.createElement("div");
    el.textContent = texto;
    el.style.cssText = `
        position: absolute; z-index: 20; pointer-events: none;
        color: ${color}; font-size: 1.4rem; font-weight: bold;
        text-shadow: 0 0 10px ${color};
        left: ${x}px; top: ${y}px;
    `;
    document.getElementById("stage").appendChild(el);

    let op = 1, posY = y;
    const anim = setInterval(() => {
        op -= 0.05; posY -= 2;
        el.style.opacity = op;
        el.style.top = posY + "px";
        if (op <= 0) { clearInterval(anim); el.remove(); }
    }, 30);
}

// --- Evaluar input del usuario ---
function evaluarInput(keyId) {
    const currentTime = ((performance.now() - getStartTime()) / 1000) * VELOCIDAD;
    const notas = getNotasEnPantalla();

    let mejorNota = null, mejorDelta = Infinity;
    for (const n of notas) {
        if (n.keyId !== keyId) continue;
        const delta = Math.abs(n.timestamp - currentTime);
        if (delta < mejorDelta) { mejorDelta = delta; mejorNota = n; }
    }

    if (mejorNota && mejorDelta <= VENTANA_HIT) {
        score += racha >= 10 ? 200 : 100;
        racha++;
        maxRacha = Math.max(maxRacha, racha);
        const x = parseFloat(mejorNota.el.style.left);
        const y = mejorNota.destinoY - 30;
        mostrarFeedback(racha >= 10 ? "Perfecto" : "Bien", "lime", x, y);
        mejorNota.el.remove();
        notas.splice(notas.indexOf(mejorNota), 1);
    } else {
        racha = 0;
        mostrarFeedback("Mal", "red", 130, 400);
    }

    actualizarPantalla();
}

const mapaInput = {
    "a": "C4",  "s": "D4",  "d": "E4",  "f": "F4",
    "g": "G4",  "h": "A4",  "j": "B4",  "k": "C5"
};

document.addEventListener("keydown", e => {
    const keyId = mapaInput[e.key];
    if (keyId) evaluarInput(keyId);
});

function onNotaLlegó(nota) {
    activarNota(nota.keyId);
    racha = 0;
    actualizarPantalla();
}

async function init() {
    const img = document.querySelector(".sax-img");
    await new Promise(r => { if (img.complete) r(); else img.onload = r; });
    calcularDestinos();
    const notas = await cargarMidi("escala.mid");
    iniciarLoop(notas, performance.now(), onNotaLlegó);
    actualizarPantalla();
}

init();
window._test = { evaluarInput, score: () => score, racha: () => racha };