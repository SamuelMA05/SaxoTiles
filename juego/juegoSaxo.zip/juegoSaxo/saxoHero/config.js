export const TIEMPO_ANTICIPACION = 3;
export const VELOCIDAD = 0.75;
export const VENTANA_HIT = 0.15;

export const MAPA_NOTAS = {
    "C4": "C4",
    "C#4": "C4S", "Db4": "C4S",
    "D4": "D4",
    "D#4": "D4S", "Eb4": "D4S",
    "E4": "E4",
    "F4": "F4",
    "F#4": "F4S", "Gb4": "F4S",
    "G4": "G4",
    "G#4": "G4S", "Ab4": "G4S",
    "A4": "A4",
    "A#4": "A4S", "Bb4": "A4S",
    "B4": "B4",
    "C5": "C5",
    "C#5": "C5S", "Db5": "C5S",
    "D5": "D5",
    "D#5": "D5S", "Eb5": "D5S",
    "E5": "E5",
    "F5": "F5",
};