import { Midi } from "https://esm.sh/@tonejs/midi";
import { TIEMPO_ANTICIPACION, VELOCIDAD, MAPA_NOTAS } from "./config.js";

const destinosTeclas = {};
let notasEnPantalla = [];
let notas = [];
let startTime = 0;

const track = document.getElementById("track");

// --- Destinos ---
export function calcularDestinos() {
    const stage = document.getElementById("stage");
    const stageRect = stage.getBoundingClientRect();
    const idsUnicos = [...new Set(Object.values(MAPA_NOTAS))];
    idsUnicos.forEach(keyId => {
        const el = document.getElementById(keyId);
        if (!el) return;
        const rect = el.getBoundingClientRect();
        destinosTeclas[keyId] = {
            x: rect.left - stageRect.left,
            y: rect.top  - stageRect.top
        };
    });
}

// --- Activar tecla visual ---
export function activarNota(keyId) {
    const el = document.getElementById(keyId);
    if (!el) return;
    el.classList.add("active");
    setTimeout(() => el.classList.remove("active"), 150);
}

// --- Crear nota visual ---
function crearNota(data) {
    const keyId = MAPA_NOTAS[data.pitch];
    if (!keyId) return null;
    const destino = destinosTeclas[keyId];
    if (!destino) return null;

    const el = document.createElement("div");
    el.classList.add("note");
    el.style.left = destino.x + "px";
    el.style.top  = "-20px";
    track.appendChild(el);

    return { el, keyId, pitch: data.pitch, timestamp: data.start, destinoY: destino.y };
}

// --- Cargar MIDI ---
export async function cargarMidi(url) {
    const res = await fetch(url);
    const buffer = await res.arrayBuffer();
    const midi = new Midi(buffer);
    const resultado = [];
    midi.tracks.forEach(t => {
        t.notes.forEach(n => {
            resultado.push({ nota: n.name, start: n.time, end: n.time + n.duration, spawned: false });
        });
    });
    resultado.sort((a, b) => a.start - b.start);
    return resultado;
}

// --- Loop ---
export function iniciarLoop(notasCargadas, tInicio, onNotaLlegó) {
    notas = notasCargadas;
    startTime = tInicio;

    function loop() {
        const currentTime = ((performance.now() - startTime) / 1000) * VELOCIDAD;

        // Spawn
        notas.forEach(n => {
            if (!n.spawned && n.start <= currentTime + TIEMPO_ANTICIPACION) {
                const nueva = crearNota({ pitch: n.nota, start: n.start });
                if (nueva) { notasEnPantalla.push(nueva); n.spawned = true; }
            }
        });

        // Mover
        for (let i = notasEnPantalla.length - 1; i >= 0; i--) {
            const nota = notasEnPantalla[i];
            const tiempoRestante = nota.timestamp - currentTime;
            const progreso = tiempoRestante / TIEMPO_ANTICIPACION;
            nota.el.style.top = (nota.destinoY * (1 - progreso) - 20 * progreso) + "px";

            if (progreso <= 0) {
                onNotaLlegó(nota);   // 👈 avisa a main.js que llegó la nota
                nota.el.remove();
                notasEnPantalla.splice(i, 1);
            }
        }

        requestAnimationFrame(loop);
    }

    loop();
}

// --- Exponer notasEnPantalla para que main.js pueda evaluarlas ---
export function getNotasEnPantalla() { return notasEnPantalla; }
export function getStartTime()       { return startTime; }